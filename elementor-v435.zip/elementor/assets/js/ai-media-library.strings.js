__( 'Edit with Elementor AI', 'elementor' );
__( 'Edit with Elementor AI', 'elementor' );
__( 'Generate with Elementor AI', 'elementor' );