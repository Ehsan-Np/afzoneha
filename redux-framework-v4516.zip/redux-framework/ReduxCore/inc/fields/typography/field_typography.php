<?php
/**
 * Silence is golden.
 *
 * @package Redux Framework
 */

defined( 'ABSPATH' ) || exit;

$redux_theme = wp_get_theme();

// translators: %1$s: template path.
echo '<div class="error"><p>' . sprintf( esc_html__( 'The Redux 3 file ReduxCore/inc/fields/typography/typography.php is still in use by %1$s. Please contact the author of this theme (NOT Redux support, we have no control over this issue). They need to update their project to use Redux 4 and discontinue use of this file. It will soon be removed from Redux.', 'redux-framework' ), '<code>' . esc_html( $redux_theme->get( 'Name' ) ) . '</code>' ) . '</p></div>';

_deprecated_file( 'ReduxCore/inc/fields/typography/typography.php', '4.3', 'redux-core/inc/fields/class-redux-typography.php', 'This file has been discontinued and is no longer used in Redux 4.  Please remove any references to it as it will be removed in future versions of Redux.' );
